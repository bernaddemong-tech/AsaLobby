# AsaLobby 1.0.0

World-specific lobby core for AsaMC, made for PaperMC.

## Target

- Java 25
- Paper API 1.21.11 (compile target)
- `plugin.yml` API version: `1.21.11`
- Intended server range: Paper 1.21.11 through Paper 26.3
- Multiverse-Core is optional; AsaLobby checks the Bukkit world name directly.
- No Velocity or BungeeCord required.

**Java runtime note:** This project is compiled as Java 25 bytecode. Run the server with Java 25 even when the server version is Paper 1.21.11. Paper 1.21.11 normally recommends Java 21, but a Java 21 runtime cannot load Java 25 bytecode. Paper 26.1+ requires Java 25.

## Features

- Lobby items are only issued while a player is in the configured lobby world.
- Compass opens the configurable Game Selector GUI.
- Each enabled minigame in `config.yml` becomes one GUI item.
- Clicking a minigame runs its configured command **as the player**. For example, `mm arenas` opens Murder Mystery's own arena GUI if that command is implemented by the installed Murder Mystery plugin and the player has permission to use it.
- Green Dye shows other players; Gray Dye hides other players.
- Player visibility preference is saved in `player-data.yml`.
- Lobby items cannot be dropped or moved through normal inventory interactions.
- `/asalobby reload` reloads the configuration and refreshes lobby items.

## Build

Install JDK 25 and Maven, then run this in the project folder:

```bash
mvn clean package
```

The compiled plugin will be created at:

```text
target/AsaLobby-1.0.0.jar
```

## Install

1. Put `AsaLobby-1.0.0.jar` in the Paper server's `plugins` folder.
2. Start the server once to generate `plugins/AsaLobby/config.yml`.
3. Set `lobby.world` to the exact world name used by your lobby (for example `spawn`).
4. Edit the enabled games, items, names, slots, and commands.
5. Restart the server, or run `/asalobby reload` as an operator.

No Multiverse-Core dependency is required. If Multiverse is installed, the world name configured in Multiverse must match `lobby.world`.

## Example Murder Mystery integration

The default example is already configured:

```yaml
selector:
  title: "&8AsaMC &8| &bGame Selector"
  rows: 3
  games:
    murder-mystery:
      enabled: true
      material: IRON_SWORD
      slot: 13
      name: "&c&lMurder Mystery"
      lore:
        - "&7Enter Murder Mystery"
        - "&eClick to select an arena"
      command: "mm arenas"
      permission: ""
```

AsaLobby does not recreate the Murder Mystery arena menu. It closes the Game Selector and dispatches `mm arenas` as the clicking player, so the Murder Mystery plugin handles its own GUI.

## Adding more minigames

Copy another section under `selector.games`, give it a unique slot, set `enabled: true`, and set the command provided by that minigame plugin. The GUI size is controlled by `selector.rows` (1 to 6 rows, 9 slots per row).

Example:

```yaml
bedwars:
  enabled: true
  material: RED_BED
  slot: 11
  name: "&c&lBedWars"
  lore:
    - "&7Choose a BedWars arena"
  command: "bw arenas"
  permission: ""
```

The command above is only an example; use the actual command registered by the BedWars plugin installed on your server.

## Important configuration notes

- Lobby item slots are hotbar slots `0` through `8` (config values `0` to `8`).
- Default lobby item slots: Compass `4`, Green Dye `7`, Gray Dye `8`.
- Default behavior protects existing inventory items. If a configured slot is occupied, AsaLobby skips that item and sends a message. Empty the slot or set `lobby.replace-existing-slots: true` if you intentionally want AsaLobby to replace it.
- Game Selector slots start at `0` and must fit inside `selector.rows * 9`.
- Minigame commands run as the player, not as console. The player must have permission for the command if the other plugin requires it.
- The configured lobby world is matched by world name, case-insensitively. Lobby features are disabled outside that world.

## Admin command

```text
/asalobby reload
```

Permission: `asalobby.admin` (default: op).
