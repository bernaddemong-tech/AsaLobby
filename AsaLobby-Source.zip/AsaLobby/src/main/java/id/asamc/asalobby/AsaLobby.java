package id.asamc.asalobby;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AsaLobby 1.0.0
 * A lightweight, world-specific lobby core for Paper servers.
 */
public final class AsaLobby extends JavaPlugin implements Listener {
    private static final String ITEM_GAME_SELECTOR = "game_selector";
    private static final String ITEM_SHOW_PLAYERS = "show_players";
    private static final String ITEM_HIDE_PLAYERS = "hide_players";

    private NamespacedKey lobbyItemKey;
    private File playerDataFile;
    private YamlConfiguration playerData;

    private String lobbyWorldName;
    private boolean replaceExistingSlots;
    private String selectorTitle;
    private int selectorRows;

    private final Map<Integer, GameEntry> gameEntries = new HashMap<>();
    private final Map<UUID, Boolean> hiddenPreferences = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        lobbyItemKey = new NamespacedKey(this, "lobby_item");
        loadPlayerData();
        loadSettings();

        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("AsaLobby 1.0.0 enabled. Lobby world: " + lobbyWorldName);

        // Re-apply lobby items when the plugin is enabled while players are online.
        for (Player player : Bukkit.getOnlinePlayers()) {
            Bukkit.getScheduler().runTask(this, () -> refreshPlayer(player));
        }
    }

    @Override
    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            removeLobbyItems(player);
            showAllPlayers(player);
        }
        savePlayerData();
        getLogger().info("AsaLobby disabled.");
    }

    private void loadSettings() {
        reloadConfig();
        lobbyWorldName = getConfig().getString("lobby.world", "spawn");
        replaceExistingSlots = getConfig().getBoolean("lobby.replace-existing-slots", false);
        selectorTitle = color(getConfig().getString("selector.title", "&8AsaMC | Game Selector"));
        selectorRows = Math.max(1, Math.min(6, getConfig().getInt("selector.rows", 3)));

        gameEntries.clear();
        ConfigurationSection games = getConfig().getConfigurationSection("selector.games");
        if (games == null) {
            return;
        }

        for (String gameId : games.getKeys(false)) {
            String path = "selector.games." + gameId;
            if (!getConfig().getBoolean(path + ".enabled", false)) {
                continue;
            }

            int slot = getConfig().getInt(path + ".slot", -1);
            if (slot < 0 || slot >= selectorRows * 9) {
                getLogger().warning("Skipping game '" + gameId + "': slot must be between 0 and "
                        + (selectorRows * 9 - 1) + ".");
                continue;
            }

            Material material = Material.matchMaterial(getConfig().getString(path + ".material", "PAPER"));
            if (material == null || material.isAir()) {
                getLogger().warning("Skipping game '" + gameId + "': invalid material.");
                continue;
            }

            if (gameEntries.containsKey(slot)) {
                getLogger().warning("Skipping game '" + gameId + "': slot " + slot + " is already used.");
                continue;
            }

            String name = getConfig().getString(path + ".name", "&f" + gameId);
            List<String> lore = getConfig().getStringList(path + ".lore");
            String command = getConfig().getString(path + ".command", "").trim();
            String permission = getConfig().getString(path + ".permission", "").trim();
            gameEntries.put(slot, new GameEntry(material, name, lore, command, permission));
        }
    }

    private void loadPlayerData() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().warning("Could not create plugin data folder.");
        }
        playerDataFile = new File(getDataFolder(), "player-data.yml");
        if (!playerDataFile.exists()) {
            try {
                if (!playerDataFile.createNewFile()) {
                    getLogger().warning("Could not create player-data.yml.");
                }
            } catch (IOException exception) {
                getLogger().severe("Could not create player-data.yml: " + exception.getMessage());
            }
        }
        playerData = YamlConfiguration.loadConfiguration(playerDataFile);

        ConfigurationSection hidden = playerData.getConfigurationSection("hidden");
        if (hidden == null) {
            return;
        }
        for (String uuidText : hidden.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidText);
                hiddenPreferences.put(uuid, hidden.getBoolean(uuidText, false));
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("Ignoring invalid UUID in player-data.yml: " + uuidText);
            }
        }
    }

    private void savePlayerData() {
        if (playerData == null || playerDataFile == null) {
            return;
        }
        for (Map.Entry<UUID, Boolean> entry : hiddenPreferences.entrySet()) {
            playerData.set("hidden." + entry.getKey(), entry.getValue());
        }
        try {
            playerData.save(playerDataFile);
        } catch (IOException exception) {
            getLogger().severe("Could not save player-data.yml: " + exception.getMessage());
        }
    }

    private boolean isLobbyWorld(Player player) {
        World world = player.getWorld();
        return world != null && world.getName().equalsIgnoreCase(lobbyWorldName);
    }

    private boolean isHidden(Player player) {
        return hiddenPreferences.getOrDefault(player.getUniqueId(), false);
    }

    private void refreshPlayer(Player player) {
        if (!player.isOnline()) {
            return;
        }
        if (isLobbyWorld(player)) {
            giveLobbyItems(player);
        } else {
            removeLobbyItems(player);
        }
        synchronizeVisibility();
    }

    private void giveLobbyItems(Player player) {
        PlayerInventory inventory = player.getInventory();
        removeLobbyItems(player);

        addLobbyItem(player, inventory, "items.game-selector", ITEM_GAME_SELECTOR);
        addLobbyItem(player, inventory, "items.visible-player", ITEM_SHOW_PLAYERS);
        addLobbyItem(player, inventory, "items.hide-player", ITEM_HIDE_PLAYERS);
    }

    private void addLobbyItem(Player player, PlayerInventory inventory, String path, String itemType) {
        if (!getConfig().getBoolean(path + ".enabled", true)) {
            return;
        }

        int slot = getConfig().getInt(path + ".slot", -1);
        if (slot < 0 || slot > 8) {
            getLogger().warning("Invalid hotbar slot for " + path + ". Use a value from 0 to 8.");
            return;
        }

        Material material = Material.matchMaterial(getConfig().getString(path + ".material", "PAPER"));
        if (material == null || material.isAir()) {
            getLogger().warning("Invalid material for " + path + ".");
            return;
        }

        ItemStack current = inventory.getItem(slot);
        if (current != null && !current.getType().isAir() && !isLobbyItem(current) && !replaceExistingSlots) {
            sendMessage(player, "slot-occupied", "%slot%", Integer.toString(slot + 1));
            return;
        }

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(getConfig().getString(path + ".name", "&fLobby Item")));
            List<String> configuredLore = getConfig().getStringList(path + ".lore");
            List<String> lore = new ArrayList<>();
            for (String line : configuredLore) {
                lore.add(color(line));
            }
            if (!lore.isEmpty()) {
                meta.setLore(lore);
            }
            meta.getPersistentDataContainer().set(lobbyItemKey, PersistentDataType.STRING, itemType);
            item.setItemMeta(meta);
        }
        inventory.setItem(slot, item);
    }

    private void removeLobbyItems(Player player) {
        PlayerInventory inventory = player.getInventory();
        ItemStack[] contents = inventory.getContents();
        for (int slot = 0; slot < contents.length; slot++) {
            if (isLobbyItem(contents[slot])) {
                inventory.setItem(slot, null);
            }
        }
    }

    private boolean isLobbyItem(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) {
            return false;
        }
        String type = item.getItemMeta().getPersistentDataContainer().get(lobbyItemKey, PersistentDataType.STRING);
        return type != null;
    }

    private String getLobbyItemType(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) {
            return null;
        }
        return item.getItemMeta().getPersistentDataContainer().get(lobbyItemKey, PersistentDataType.STRING);
    }

    private void openGameSelector(Player player) {
        if (gameEntries.isEmpty()) {
            sendMessage(player, "no-games");
            return;
        }

        GameSelectorHolder holder = new GameSelectorHolder();
        Inventory inventory = Bukkit.createInventory(holder, selectorRows * 9, selectorTitle);
        holder.setInventory(inventory);

        for (Map.Entry<Integer, GameEntry> entry : gameEntries.entrySet()) {
            GameEntry game = entry.getValue();
            ItemStack item = new ItemStack(game.material);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(color(game.name));
                List<String> lore = new ArrayList<>();
                for (String line : game.lore) {
                    lore.add(color(line));
                }
                if (!lore.isEmpty()) {
                    meta.setLore(lore);
                }
                item.setItemMeta(meta);
            }
            inventory.setItem(entry.getKey(), item);
        }

        player.openInventory(inventory);
    }

    private void executeGameCommand(Player player, GameEntry game) {
        if (!game.permission.isEmpty() && !player.hasPermission(game.permission)) {
            sendMessage(player, "game-permission");
            return;
        }
        if (game.command.isBlank()) {
            sendMessage(player, "command-missing");
            return;
        }

        String command = game.command.startsWith("/") ? game.command.substring(1) : game.command;
        command = command.replace("{player}", player.getName())
                .replace("{uuid}", player.getUniqueId().toString())
                .trim();
        if (command.isEmpty()) {
            sendMessage(player, "command-missing");
            return;
        }

        // Run it as the player (not console) so plugins can open their own player GUIs.
        player.performCommand(command);
    }

    private void hideOtherPlayers(Player viewer) {
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (target.equals(viewer) || !isLobbyWorld(target)) {
                continue;
            }
            viewer.hidePlayer(this, target);
        }
    }

    private void showOtherPlayers(Player viewer) {
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (target.equals(viewer)) {
                continue;
            }
            viewer.showPlayer(this, target);
        }
    }

    private void showAllPlayers(Player viewer) {
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (!target.equals(viewer)) {
                viewer.showPlayer(this, target);
            }
        }
    }

    private void synchronizeVisibility() {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (!isLobbyWorld(viewer)) {
                showAllPlayers(viewer);
            } else if (isHidden(viewer)) {
                hideOtherPlayers(viewer);
            } else {
                showOtherPlayers(viewer);
            }
        }
    }

    private void setPlayersHidden(Player player, boolean hidden) {
        hiddenPreferences.put(player.getUniqueId(), hidden);
        savePlayerData();
        synchronizeVisibility();
        sendMessage(player, hidden ? "players-hidden" : "players-visible");
    }

    private void sendMessage(Player player, String key) {
        sendMessage(player, key, null, null);
    }

    private void sendMessage(Player player, String key, String placeholder, String value) {
        String prefix = getConfig().getString("messages.prefix", "&8[&bAsaLobby&8] ");
        String message = getConfig().getString("messages." + key, "");
        if (message.isEmpty()) {
            return;
        }
        if (placeholder != null && value != null) {
            message = message.replace(placeholder, value);
        }
        player.sendMessage(color(prefix + message));
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("asalobby.admin")) {
                sender.sendMessage(color(getConfig().getString("messages.prefix", "&8[&bAsaLobby&8] ")
                        + getConfig().getString("messages.no-permission", "&cNo permission.")));
                return true;
            }

            loadSettings();
            for (Player player : Bukkit.getOnlinePlayers()) {
                removeLobbyItems(player);
                if (isLobbyWorld(player)) {
                    giveLobbyItems(player);
                }
            }
            synchronizeVisibility();
            sender.sendMessage(color(getConfig().getString("messages.prefix", "&8[&bAsaLobby&8] ")
                    + getConfig().getString("messages.reloaded", "&aConfiguration reloaded.")));
            return true;
        }

        sender.sendMessage(color("&bAsaLobby &7v1.0.0 &8- &f/asalobby reload"));
        return true;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTask(this, () -> refreshPlayer(event.getPlayer()));
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        refreshPlayer(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Bukkit.getScheduler().runTask(this, () -> refreshPlayer(event.getPlayer()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        savePlayerData();
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        ItemStack item = event.getItem();
        String itemType = getLobbyItemType(item);
        if (itemType == null) {
            return;
        }

        event.setCancelled(true);
        if (!isLobbyWorld(event.getPlayer())) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player player = event.getPlayer();
        switch (itemType) {
            case ITEM_GAME_SELECTOR -> openGameSelector(player);
            case ITEM_SHOW_PLAYERS -> setPlayersHidden(player, false);
            case ITEM_HIDE_PLAYERS -> setPlayersHidden(player, true);
            default -> {
                // Unknown item marker; keep the marked item from triggering vanilla behavior.
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof GameSelectorHolder) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) {
                return;
            }
            int rawSlot = event.getRawSlot();
            if (rawSlot < 0 || rawSlot >= event.getView().getTopInventory().getSize()) {
                return;
            }
            GameEntry game = gameEntries.get(rawSlot);
            if (game == null) {
                return;
            }
            player.closeInventory();
            Bukkit.getScheduler().runTask(this, () -> {
                if (player.isOnline()) {
                    executeGameCommand(player, game);
                }
            });
            return;
        }

        if (isLobbyItem(event.getCurrentItem()) || isLobbyItem(event.getCursor())) {
            event.setCancelled(true);
            return;
        }
        if (event.getHotbarButton() >= 0 && event.getWhoClicked() instanceof Player player) {
            ItemStack hotbarItem = player.getInventory().getItem(event.getHotbarButton());
            if (isLobbyItem(hotbarItem)) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof GameSelectorHolder
                || isLobbyItem(event.getOldCursor())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (isLobbyItem(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        event.getDrops().removeIf(this::isLobbyItem);
    }

    private static final class GameEntry {
        private final Material material;
        private final String name;
        private final List<String> lore;
        private final String command;
        private final String permission;

        private GameEntry(Material material, String name, List<String> lore, String command, String permission) {
            this.material = material;
            this.name = name;
            this.lore = new ArrayList<>(lore);
            this.command = command;
            this.permission = permission;
        }
    }
}
